SOCI Documentation
==================

The `/www/doc` directory is a placeholder for documentation published
online, with subdirectories of versioned documentation, one per each
branch (`master`, `release/3.2`, etc.), that is:

* doc/master
* doc/release/3.2
* doc/release/3.1

Documentation pages are copied from /doc directory of each release.
