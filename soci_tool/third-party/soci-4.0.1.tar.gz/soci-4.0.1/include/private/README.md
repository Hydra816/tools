# soci/include/private

Private headers do not define any parts of public interface,
are not installed in user's filesystem.
Private headers only define common features used internally.
